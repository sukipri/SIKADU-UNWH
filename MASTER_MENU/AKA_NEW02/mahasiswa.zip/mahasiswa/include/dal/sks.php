<?php
$dalTablesks = array();
$dalTablesks["idmainsks"] = array("type"=>3,"varname"=>"idmainsks");
$dalTablesks["idsks"] = array("type"=>200,"varname"=>"idsks");
$dalTablesks["iddosen"] = array("type"=>200,"varname"=>"iddosen");
$dalTablesks["idsemester"] = array("type"=>200,"varname"=>"idsemester");
$dalTablesks["idkejuruan"] = array("type"=>200,"varname"=>"idkejuruan");
$dalTablesks["idruang"] = array("type"=>200,"varname"=>"idruang");
$dalTablesks["idkurikulum"] = array("type"=>200,"varname"=>"idkurikulum");
$dalTablesks["judul"] = array("type"=>200,"varname"=>"judul");
$dalTablesks["jumlah"] = array("type"=>200,"varname"=>"jumlah");
$dalTablesks["hari"] = array("type"=>200,"varname"=>"hari");
$dalTablesks["jam"] = array("type"=>200,"varname"=>"jam");
$dalTablesks["idkelas"] = array("type"=>200,"varname"=>"idkelas");
$dalTablesks["kuota"] = array("type"=>200,"varname"=>"kuota");
$dalTablesks["app"] = array("type"=>129,"varname"=>"app");
$dalTablesks["batas_dosen"] = array("type"=>7,"varname"=>"batas_dosen");
	$dalTablesks["idmainsks"]["key"]=true;
$dal_info["sks"]=&$dalTablesks;

?>