<?php
$dalTableabsen = array();
$dalTableabsen["idabsen"] = array("type"=>3,"varname"=>"idabsen");
$dalTableabsen["idmahasiswa"] = array("type"=>200,"varname"=>"idmahasiswa");
$dalTableabsen["idsks"] = array("type"=>200,"varname"=>"idsks");
$dalTableabsen["idpraktikum"] = array("type"=>200,"varname"=>"idpraktikum");
$dalTableabsen["status"] = array("type"=>200,"varname"=>"status");
$dalTableabsen["jenis"] = array("type"=>129,"varname"=>"jenis");
$dalTableabsen["tgl"] = array("type"=>7,"varname"=>"tgl");
$dalTableabsen["idsemester"] = array("type"=>200,"varname"=>"idsemester");
$dalTableabsen["app"] = array("type"=>129,"varname"=>"app");
	$dalTableabsen["idabsen"]["key"]=true;
$dal_info["absen"]=&$dalTableabsen;

?>