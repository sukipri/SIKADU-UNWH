<?php
$dalTablekrs = array();
$dalTablekrs["idkrs"] = array("type"=>3,"varname"=>"idkrs");
$dalTablekrs["idsks"] = array("type"=>200,"varname"=>"idsks");
$dalTablekrs["idmahasiswa"] = array("type"=>200,"varname"=>"idmahasiswa");
$dalTablekrs["idpraktikum"] = array("type"=>200,"varname"=>"idpraktikum");
$dalTablekrs["kt"] = array("type"=>200,"varname"=>"kt");
$dalTablekrs["ssp"] = array("type"=>200,"varname"=>"ssp");
$dalTablekrs["ts"] = array("type"=>200,"varname"=>"ts");
$dalTablekrs["nas"] = array("type"=>200,"varname"=>"nas");
$dalTablekrs["total"] = array("type"=>200,"varname"=>"total");
$dalTablekrs["angka"] = array("type"=>200,"varname"=>"angka");
$dalTablekrs["jumlah"] = array("type"=>200,"varname"=>"jumlah");
$dalTablekrs["jumlah_praktikum"] = array("type"=>200,"varname"=>"jumlah_praktikum");
$dalTablekrs["app"] = array("type"=>129,"varname"=>"app");
$dalTablekrs["idsemester"] = array("type"=>200,"varname"=>"idsemester");
$dalTablekrs["total2"] = array("type"=>200,"varname"=>"total2");
$dalTablekrs["app2"] = array("type"=>129,"varname"=>"app2");
$dalTablekrs["jenis"] = array("type"=>129,"varname"=>"jenis");
$dalTablekrs["ahr"] = array("type"=>200,"varname"=>"ahr");
	$dalTablekrs["idkrs"]["key"]=true;
$dal_info["krs"]=&$dalTablekrs;

?>