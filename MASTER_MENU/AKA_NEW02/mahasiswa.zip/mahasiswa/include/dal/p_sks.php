<?php
$dalTablep_sks = array();
$dalTablep_sks["idp_sks"] = array("type"=>3,"varname"=>"idp_sks");
$dalTablep_sks["idpraktikum"] = array("type"=>200,"varname"=>"idpraktikum");
$dalTablep_sks["idmahasiswa"] = array("type"=>200,"varname"=>"idmahasiswa");
$dalTablep_sks["idsks"] = array("type"=>200,"varname"=>"idsks");
$dalTablep_sks["kt"] = array("type"=>200,"varname"=>"kt");
$dalTablep_sks["ssp"] = array("type"=>200,"varname"=>"ssp");
$dalTablep_sks["ts"] = array("type"=>200,"varname"=>"ts");
$dalTablep_sks["nas"] = array("type"=>200,"varname"=>"nas");
$dalTablep_sks["total"] = array("type"=>200,"varname"=>"total");
$dalTablep_sks["jumlah"] = array("type"=>200,"varname"=>"jumlah");
$dalTablep_sks["app"] = array("type"=>129,"varname"=>"app");
$dalTablep_sks["idsemester"] = array("type"=>200,"varname"=>"idsemester");
$dalTablep_sks["total2"] = array("type"=>200,"varname"=>"total2");
$dalTablep_sks["app2"] = array("type"=>129,"varname"=>"app2");
	$dalTablep_sks["idp_sks"]["key"]=true;
$dal_info["p_sks"]=&$dalTablep_sks;

?>