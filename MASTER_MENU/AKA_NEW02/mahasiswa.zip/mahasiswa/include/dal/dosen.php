<?php
$dalTabledosen = array();
$dalTabledosen["iddosen"] = array("type"=>200,"varname"=>"iddosen");
$dalTabledosen["idnid"] = array("type"=>200,"varname"=>"idnid");
$dalTabledosen["idkejuruan"] = array("type"=>200,"varname"=>"idkejuruan");
$dalTabledosen["nama"] = array("type"=>200,"varname"=>"nama");
$dalTabledosen["alamat"] = array("type"=>200,"varname"=>"alamat");
$dalTabledosen["negara"] = array("type"=>200,"varname"=>"negara");
$dalTabledosen["email"] = array("type"=>200,"varname"=>"email");
$dalTabledosen["agama"] = array("type"=>200,"varname"=>"agama");
$dalTabledosen["jeniskelamin"] = array("type"=>200,"varname"=>"jeniskelamin");
$dalTabledosen["ttl"] = array("type"=>200,"varname"=>"ttl");
$dalTabledosen["noktp"] = array("type"=>200,"varname"=>"noktp");
$dalTabledosen["status"] = array("type"=>129,"varname"=>"status");
$dalTabledosen["tlp"] = array("type"=>200,"varname"=>"tlp");
$dalTabledosen["gelar"] = array("type"=>200,"varname"=>"gelar");
	$dalTabledosen["iddosen"]["key"]=true;
$dal_info["dosen"]=&$dalTabledosen;

?>