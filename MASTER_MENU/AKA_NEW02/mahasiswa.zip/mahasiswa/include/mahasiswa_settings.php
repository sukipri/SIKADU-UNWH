<?php
require_once(getabspath("classes/cipherer.php"));




$tdatamahasiswa = array();	
	$tdatamahasiswa[".truncateText"] = true;
	$tdatamahasiswa[".NumberOfChars"] = 80; 
	$tdatamahasiswa[".ShortName"] = "mahasiswa";
	$tdatamahasiswa[".OwnerID"] = "";
	$tdatamahasiswa[".OriginalTable"] = "mahasiswa";

//	field labels
$fieldLabelsmahasiswa = array();
$fieldToolTipsmahasiswa = array();
$pageTitlesmahasiswa = array();

if(mlang_getcurrentlang()=="Indonesian")
{
	$fieldLabelsmahasiswa["Indonesian"] = array();
	$fieldToolTipsmahasiswa["Indonesian"] = array();
	$pageTitlesmahasiswa["Indonesian"] = array();
	$fieldLabelsmahasiswa["Indonesian"]["idmahasiswa"] = "Idmahasiswa";
	$fieldToolTipsmahasiswa["Indonesian"]["idmahasiswa"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["idkejuruan"] = "Idkejuruan";
	$fieldToolTipsmahasiswa["Indonesian"]["idkejuruan"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["idsemester"] = "Idsemester";
	$fieldToolTipsmahasiswa["Indonesian"]["idsemester"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["idtahun_ajaran"] = "Idtahun Ajaran";
	$fieldToolTipsmahasiswa["Indonesian"]["idtahun_ajaran"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["idkelas"] = "Idkelas";
	$fieldToolTipsmahasiswa["Indonesian"]["idkelas"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["nama"] = "Nama";
	$fieldToolTipsmahasiswa["Indonesian"]["nama"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["alamat"] = "Alamat";
	$fieldToolTipsmahasiswa["Indonesian"]["alamat"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["idkota"] = "Idkota";
	$fieldToolTipsmahasiswa["Indonesian"]["idkota"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["agama"] = "Agama";
	$fieldToolTipsmahasiswa["Indonesian"]["agama"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["jeniskelamin"] = "Jeniskelamin";
	$fieldToolTipsmahasiswa["Indonesian"]["jeniskelamin"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["tgl_lahir"] = "Tgl Lahir";
	$fieldToolTipsmahasiswa["Indonesian"]["tgl_lahir"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["tempat_lahir"] = "Tempat Lahir";
	$fieldToolTipsmahasiswa["Indonesian"]["tempat_lahir"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["mhs"] = "Mhs";
	$fieldToolTipsmahasiswa["Indonesian"]["mhs"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["st"] = "St";
	$fieldToolTipsmahasiswa["Indonesian"]["st"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["uas"] = "Uas";
	$fieldToolTipsmahasiswa["Indonesian"]["uas"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["uts"] = "Uts";
	$fieldToolTipsmahasiswa["Indonesian"]["uts"] = "";
	$fieldLabelsmahasiswa["Indonesian"]["status_nim"] = "Status Nim";
	$fieldToolTipsmahasiswa["Indonesian"]["status_nim"] = "";
	if (count($fieldToolTipsmahasiswa["Indonesian"]))
		$tdatamahasiswa[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsmahasiswa[""] = array();
	$fieldToolTipsmahasiswa[""] = array();
	$pageTitlesmahasiswa[""] = array();
	$fieldLabelsmahasiswa[""]["idmahasiswa"] = "Idmahasiswa";
	$fieldToolTipsmahasiswa[""]["idmahasiswa"] = "";
	if (count($fieldToolTipsmahasiswa[""]))
		$tdatamahasiswa[".isUseToolTips"] = true;
}
	
	
	$tdatamahasiswa[".NCSearch"] = true;



$tdatamahasiswa[".shortTableName"] = "mahasiswa";
$tdatamahasiswa[".nSecOptions"] = 0;
$tdatamahasiswa[".recsPerRowList"] = 1;
$tdatamahasiswa[".mainTableOwnerID"] = "";
$tdatamahasiswa[".moveNext"] = 1;
$tdatamahasiswa[".nType"] = 0;

$tdatamahasiswa[".strOriginalTableName"] = "mahasiswa";




$tdatamahasiswa[".showAddInPopup"] = false;

$tdatamahasiswa[".showEditInPopup"] = false;

$tdatamahasiswa[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatamahasiswa[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatamahasiswa[".fieldsForRegister"] = array();

$tdatamahasiswa[".listAjax"] = false;

	$tdatamahasiswa[".audit"] = false;

	$tdatamahasiswa[".locking"] = false;

$tdatamahasiswa[".edit"] = true;

$tdatamahasiswa[".list"] = true;

$tdatamahasiswa[".view"] = true;

$tdatamahasiswa[".import"] = true;

$tdatamahasiswa[".exportTo"] = true;

$tdatamahasiswa[".printFriendly"] = true;

$tdatamahasiswa[".delete"] = true;

$tdatamahasiswa[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdatamahasiswa[".searchSaving"] = false;
//

$tdatamahasiswa[".showSearchPanel"] = true;
		$tdatamahasiswa[".flexibleSearch"] = true;		

if (isMobile())
	$tdatamahasiswa[".isUseAjaxSuggest"] = false;
else 
	$tdatamahasiswa[".isUseAjaxSuggest"] = true;

$tdatamahasiswa[".rowHighlite"] = true;



$tdatamahasiswa[".addPageEvents"] = false;

// use timepicker for search panel
$tdatamahasiswa[".isUseTimeForSearch"] = false;





$tdatamahasiswa[".allSearchFields"] = array();
$tdatamahasiswa[".filterFields"] = array();
$tdatamahasiswa[".requiredSearchFields"] = array();

$tdatamahasiswa[".allSearchFields"][] = "idmahasiswa";
	$tdatamahasiswa[".allSearchFields"][] = "idkejuruan";
	$tdatamahasiswa[".allSearchFields"][] = "idsemester";
	$tdatamahasiswa[".allSearchFields"][] = "idtahun_ajaran";
	$tdatamahasiswa[".allSearchFields"][] = "idkelas";
	$tdatamahasiswa[".allSearchFields"][] = "nama";
	$tdatamahasiswa[".allSearchFields"][] = "alamat";
	$tdatamahasiswa[".allSearchFields"][] = "idkota";
	$tdatamahasiswa[".allSearchFields"][] = "agama";
	$tdatamahasiswa[".allSearchFields"][] = "jeniskelamin";
	$tdatamahasiswa[".allSearchFields"][] = "tgl_lahir";
	$tdatamahasiswa[".allSearchFields"][] = "tempat_lahir";
	$tdatamahasiswa[".allSearchFields"][] = "mhs";
	$tdatamahasiswa[".allSearchFields"][] = "st";
	$tdatamahasiswa[".allSearchFields"][] = "uas";
	$tdatamahasiswa[".allSearchFields"][] = "uts";
	$tdatamahasiswa[".allSearchFields"][] = "status_nim";
	

$tdatamahasiswa[".googleLikeFields"] = array();
$tdatamahasiswa[".googleLikeFields"][] = "idmahasiswa";
$tdatamahasiswa[".googleLikeFields"][] = "idkejuruan";
$tdatamahasiswa[".googleLikeFields"][] = "idsemester";
$tdatamahasiswa[".googleLikeFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".googleLikeFields"][] = "idkelas";
$tdatamahasiswa[".googleLikeFields"][] = "nama";
$tdatamahasiswa[".googleLikeFields"][] = "alamat";
$tdatamahasiswa[".googleLikeFields"][] = "idkota";
$tdatamahasiswa[".googleLikeFields"][] = "agama";
$tdatamahasiswa[".googleLikeFields"][] = "jeniskelamin";
$tdatamahasiswa[".googleLikeFields"][] = "tgl_lahir";
$tdatamahasiswa[".googleLikeFields"][] = "tempat_lahir";
$tdatamahasiswa[".googleLikeFields"][] = "mhs";
$tdatamahasiswa[".googleLikeFields"][] = "st";
$tdatamahasiswa[".googleLikeFields"][] = "uas";
$tdatamahasiswa[".googleLikeFields"][] = "uts";
$tdatamahasiswa[".googleLikeFields"][] = "status_nim";


$tdatamahasiswa[".advSearchFields"] = array();
$tdatamahasiswa[".advSearchFields"][] = "idmahasiswa";
$tdatamahasiswa[".advSearchFields"][] = "idkejuruan";
$tdatamahasiswa[".advSearchFields"][] = "idsemester";
$tdatamahasiswa[".advSearchFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".advSearchFields"][] = "idkelas";
$tdatamahasiswa[".advSearchFields"][] = "nama";
$tdatamahasiswa[".advSearchFields"][] = "alamat";
$tdatamahasiswa[".advSearchFields"][] = "idkota";
$tdatamahasiswa[".advSearchFields"][] = "agama";
$tdatamahasiswa[".advSearchFields"][] = "jeniskelamin";
$tdatamahasiswa[".advSearchFields"][] = "tgl_lahir";
$tdatamahasiswa[".advSearchFields"][] = "tempat_lahir";
$tdatamahasiswa[".advSearchFields"][] = "mhs";
$tdatamahasiswa[".advSearchFields"][] = "st";
$tdatamahasiswa[".advSearchFields"][] = "uas";
$tdatamahasiswa[".advSearchFields"][] = "uts";
$tdatamahasiswa[".advSearchFields"][] = "status_nim";

$tdatamahasiswa[".tableType"] = "list";

$tdatamahasiswa[".printerPageOrientation"] = 0;
$tdatamahasiswa[".nPrinterPageScale"] = 100;

$tdatamahasiswa[".nPrinterSplitRecords"] = 40;

$tdatamahasiswa[".nPrinterPDFSplitRecords"] = 40;





	





// view page pdf

// print page pdf


$tdatamahasiswa[".pageSize"] = 20;

$tdatamahasiswa[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatamahasiswa[".strOrderBy"] = $tstrOrderBy;

$tdatamahasiswa[".orderindexes"] = array();

$tdatamahasiswa[".sqlHead"] = "SELECT idmahasiswa,  idkejuruan,  idsemester,  idtahun_ajaran,  idkelas,  nama,  alamat,  idkota,  agama,  jeniskelamin,  tgl_lahir,  tempat_lahir,  mhs,  st,  uas,  uts,  status_nim";
$tdatamahasiswa[".sqlFrom"] = "FROM mahasiswa";
$tdatamahasiswa[".sqlWhereExpr"] = "";
$tdatamahasiswa[".sqlTail"] = "";




//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatamahasiswa[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatamahasiswa[".arrGroupsPerPage"] = $arrGPP;

$tdatamahasiswa[".highlightSearchResults"] = true;

$tableKeysmahasiswa = array();
$tableKeysmahasiswa[] = "idmahasiswa";
$tdatamahasiswa[".Keys"] = $tableKeysmahasiswa;

$tdatamahasiswa[".listFields"] = array();
$tdatamahasiswa[".listFields"][] = "idmahasiswa";
$tdatamahasiswa[".listFields"][] = "idkejuruan";
$tdatamahasiswa[".listFields"][] = "idsemester";
$tdatamahasiswa[".listFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".listFields"][] = "idkelas";
$tdatamahasiswa[".listFields"][] = "nama";
$tdatamahasiswa[".listFields"][] = "alamat";
$tdatamahasiswa[".listFields"][] = "idkota";
$tdatamahasiswa[".listFields"][] = "agama";
$tdatamahasiswa[".listFields"][] = "jeniskelamin";
$tdatamahasiswa[".listFields"][] = "tgl_lahir";
$tdatamahasiswa[".listFields"][] = "tempat_lahir";
$tdatamahasiswa[".listFields"][] = "mhs";
$tdatamahasiswa[".listFields"][] = "st";
$tdatamahasiswa[".listFields"][] = "uas";
$tdatamahasiswa[".listFields"][] = "uts";
$tdatamahasiswa[".listFields"][] = "status_nim";

$tdatamahasiswa[".hideMobileList"] = array();


$tdatamahasiswa[".viewFields"] = array();
$tdatamahasiswa[".viewFields"][] = "idmahasiswa";
$tdatamahasiswa[".viewFields"][] = "idkejuruan";
$tdatamahasiswa[".viewFields"][] = "idsemester";
$tdatamahasiswa[".viewFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".viewFields"][] = "idkelas";
$tdatamahasiswa[".viewFields"][] = "nama";
$tdatamahasiswa[".viewFields"][] = "alamat";
$tdatamahasiswa[".viewFields"][] = "idkota";
$tdatamahasiswa[".viewFields"][] = "agama";
$tdatamahasiswa[".viewFields"][] = "jeniskelamin";
$tdatamahasiswa[".viewFields"][] = "tgl_lahir";
$tdatamahasiswa[".viewFields"][] = "tempat_lahir";
$tdatamahasiswa[".viewFields"][] = "mhs";
$tdatamahasiswa[".viewFields"][] = "st";
$tdatamahasiswa[".viewFields"][] = "uas";
$tdatamahasiswa[".viewFields"][] = "uts";
$tdatamahasiswa[".viewFields"][] = "status_nim";

$tdatamahasiswa[".addFields"] = array();
$tdatamahasiswa[".addFields"][] = "idmahasiswa";
$tdatamahasiswa[".addFields"][] = "idkejuruan";
$tdatamahasiswa[".addFields"][] = "idsemester";
$tdatamahasiswa[".addFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".addFields"][] = "idkelas";
$tdatamahasiswa[".addFields"][] = "nama";
$tdatamahasiswa[".addFields"][] = "alamat";
$tdatamahasiswa[".addFields"][] = "idkota";
$tdatamahasiswa[".addFields"][] = "agama";
$tdatamahasiswa[".addFields"][] = "jeniskelamin";
$tdatamahasiswa[".addFields"][] = "tgl_lahir";
$tdatamahasiswa[".addFields"][] = "tempat_lahir";
$tdatamahasiswa[".addFields"][] = "mhs";
$tdatamahasiswa[".addFields"][] = "st";
$tdatamahasiswa[".addFields"][] = "uas";
$tdatamahasiswa[".addFields"][] = "uts";
$tdatamahasiswa[".addFields"][] = "status_nim";

$tdatamahasiswa[".inlineAddFields"] = array();

$tdatamahasiswa[".editFields"] = array();
$tdatamahasiswa[".editFields"][] = "idmahasiswa";
$tdatamahasiswa[".editFields"][] = "idkejuruan";
$tdatamahasiswa[".editFields"][] = "idsemester";
$tdatamahasiswa[".editFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".editFields"][] = "idkelas";
$tdatamahasiswa[".editFields"][] = "nama";
$tdatamahasiswa[".editFields"][] = "alamat";
$tdatamahasiswa[".editFields"][] = "idkota";
$tdatamahasiswa[".editFields"][] = "agama";
$tdatamahasiswa[".editFields"][] = "jeniskelamin";
$tdatamahasiswa[".editFields"][] = "tgl_lahir";
$tdatamahasiswa[".editFields"][] = "tempat_lahir";
$tdatamahasiswa[".editFields"][] = "mhs";
$tdatamahasiswa[".editFields"][] = "st";
$tdatamahasiswa[".editFields"][] = "uas";
$tdatamahasiswa[".editFields"][] = "uts";
$tdatamahasiswa[".editFields"][] = "status_nim";

$tdatamahasiswa[".inlineEditFields"] = array();

$tdatamahasiswa[".exportFields"] = array();
$tdatamahasiswa[".exportFields"][] = "idmahasiswa";
$tdatamahasiswa[".exportFields"][] = "idkejuruan";
$tdatamahasiswa[".exportFields"][] = "idsemester";
$tdatamahasiswa[".exportFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".exportFields"][] = "idkelas";
$tdatamahasiswa[".exportFields"][] = "nama";
$tdatamahasiswa[".exportFields"][] = "alamat";
$tdatamahasiswa[".exportFields"][] = "idkota";
$tdatamahasiswa[".exportFields"][] = "agama";
$tdatamahasiswa[".exportFields"][] = "jeniskelamin";
$tdatamahasiswa[".exportFields"][] = "tgl_lahir";
$tdatamahasiswa[".exportFields"][] = "tempat_lahir";
$tdatamahasiswa[".exportFields"][] = "mhs";
$tdatamahasiswa[".exportFields"][] = "st";
$tdatamahasiswa[".exportFields"][] = "uas";
$tdatamahasiswa[".exportFields"][] = "uts";
$tdatamahasiswa[".exportFields"][] = "status_nim";

$tdatamahasiswa[".importFields"] = array();
$tdatamahasiswa[".importFields"][] = "idmahasiswa";
$tdatamahasiswa[".importFields"][] = "idkejuruan";
$tdatamahasiswa[".importFields"][] = "idsemester";
$tdatamahasiswa[".importFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".importFields"][] = "idkelas";
$tdatamahasiswa[".importFields"][] = "nama";
$tdatamahasiswa[".importFields"][] = "alamat";
$tdatamahasiswa[".importFields"][] = "idkota";
$tdatamahasiswa[".importFields"][] = "agama";
$tdatamahasiswa[".importFields"][] = "jeniskelamin";
$tdatamahasiswa[".importFields"][] = "tgl_lahir";
$tdatamahasiswa[".importFields"][] = "tempat_lahir";
$tdatamahasiswa[".importFields"][] = "mhs";
$tdatamahasiswa[".importFields"][] = "st";
$tdatamahasiswa[".importFields"][] = "uas";
$tdatamahasiswa[".importFields"][] = "uts";
$tdatamahasiswa[".importFields"][] = "status_nim";

$tdatamahasiswa[".printFields"] = array();
$tdatamahasiswa[".printFields"][] = "idmahasiswa";
$tdatamahasiswa[".printFields"][] = "idkejuruan";
$tdatamahasiswa[".printFields"][] = "idsemester";
$tdatamahasiswa[".printFields"][] = "idtahun_ajaran";
$tdatamahasiswa[".printFields"][] = "idkelas";
$tdatamahasiswa[".printFields"][] = "nama";
$tdatamahasiswa[".printFields"][] = "alamat";
$tdatamahasiswa[".printFields"][] = "idkota";
$tdatamahasiswa[".printFields"][] = "agama";
$tdatamahasiswa[".printFields"][] = "jeniskelamin";
$tdatamahasiswa[".printFields"][] = "tgl_lahir";
$tdatamahasiswa[".printFields"][] = "tempat_lahir";
$tdatamahasiswa[".printFields"][] = "mhs";
$tdatamahasiswa[".printFields"][] = "st";
$tdatamahasiswa[".printFields"][] = "uas";
$tdatamahasiswa[".printFields"][] = "uts";
$tdatamahasiswa[".printFields"][] = "status_nim";

//	idmahasiswa
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "idmahasiswa";
	$fdata["GoodName"] = "idmahasiswa";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idmahasiswa"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idmahasiswa"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idmahasiswa";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idmahasiswa"] = $fdata;
//	idkejuruan
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "idkejuruan";
	$fdata["GoodName"] = "idkejuruan";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idkejuruan"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idkejuruan"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idkejuruan";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idkejuruan"] = $fdata;
//	idsemester
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "idsemester";
	$fdata["GoodName"] = "idsemester";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idsemester"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idsemester"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idsemester";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idsemester"] = $fdata;
//	idtahun_ajaran
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "idtahun_ajaran";
	$fdata["GoodName"] = "idtahun_ajaran";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idtahun_ajaran"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idtahun_ajaran"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idtahun_ajaran";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idtahun_ajaran"] = $fdata;
//	idkelas
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "idkelas";
	$fdata["GoodName"] = "idkelas";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idkelas"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idkelas"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idkelas";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idkelas"] = $fdata;
//	nama
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "nama";
	$fdata["GoodName"] = "nama";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","nama"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "nama"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "nama";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["nama"] = $fdata;
//	alamat
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "alamat";
	$fdata["GoodName"] = "alamat";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","alamat"); 
	$fdata["FieldType"] = 201;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "alamat"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "alamat";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text area");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
				$edata["nRows"] = 100;
			$edata["nCols"] = 200;
	
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["alamat"] = $fdata;
//	idkota
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "idkota";
	$fdata["GoodName"] = "idkota";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","idkota"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "idkota"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "idkota";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["idkota"] = $fdata;
//	agama
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "agama";
	$fdata["GoodName"] = "agama";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","agama"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "agama"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "agama";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["agama"] = $fdata;
//	jeniskelamin
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 10;
	$fdata["strName"] = "jeniskelamin";
	$fdata["GoodName"] = "jeniskelamin";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","jeniskelamin"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "jeniskelamin"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "jeniskelamin";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["jeniskelamin"] = $fdata;
//	tgl_lahir
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 11;
	$fdata["strName"] = "tgl_lahir";
	$fdata["GoodName"] = "tgl_lahir";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","tgl_lahir"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "tgl_lahir"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "tgl_lahir";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["tgl_lahir"] = $fdata;
//	tempat_lahir
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 12;
	$fdata["strName"] = "tempat_lahir";
	$fdata["GoodName"] = "tempat_lahir";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","tempat_lahir"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "tempat_lahir"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "tempat_lahir";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["tempat_lahir"] = $fdata;
//	mhs
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 13;
	$fdata["strName"] = "mhs";
	$fdata["GoodName"] = "mhs";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","mhs"); 
	$fdata["FieldType"] = 129;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "mhs"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "mhs";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;
		
		
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "1";
	$edata["LookupValues"][] = "2";
	$edata["LookupValues"][] = "3";
	$edata["LookupValues"][] = "4";
	$edata["LookupValues"][] = "5";

		
		$edata["SelectSize"] = 1;
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["mhs"] = $fdata;
//	st
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 14;
	$fdata["strName"] = "st";
	$fdata["GoodName"] = "st";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","st"); 
	$fdata["FieldType"] = 129;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "st"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "st";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;
		
		
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "1";
	$edata["LookupValues"][] = "2";

		
		$edata["SelectSize"] = 1;
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["st"] = $fdata;
//	uas
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 15;
	$fdata["strName"] = "uas";
	$fdata["GoodName"] = "uas";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","uas"); 
	$fdata["FieldType"] = 129;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "uas"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "uas";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;
		
		
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "1";
	$edata["LookupValues"][] = "2";

		
		$edata["SelectSize"] = 1;
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["uas"] = $fdata;
//	uts
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 16;
	$fdata["strName"] = "uts";
	$fdata["GoodName"] = "uts";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","uts"); 
	$fdata["FieldType"] = 129;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "uts"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "uts";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;
		
		
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "1";
	$edata["LookupValues"][] = "2";

		
		$edata["SelectSize"] = 1;
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["uts"] = $fdata;
//	status_nim
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 17;
	$fdata["strName"] = "status_nim";
	$fdata["GoodName"] = "status_nim";
	$fdata["ownerTable"] = "mahasiswa";
	$fdata["Label"] = GetFieldLabel("mahasiswa","status_nim"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		
		$fdata["bEditPage"] = true; 
	
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "status_nim"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "status_nim";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=100";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatamahasiswa["status_nim"] = $fdata;

	
$tables_data["mahasiswa"]=&$tdatamahasiswa;
$field_labels["mahasiswa"] = &$fieldLabelsmahasiswa;
$fieldToolTips["mahasiswa"] = &$fieldToolTipsmahasiswa;
$page_titles["mahasiswa"] = &$pageTitlesmahasiswa;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["mahasiswa"] = array();
	
// tables which are master tables for current table (detail)
$masterTablesData["mahasiswa"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_mahasiswa()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "idmahasiswa,  idkejuruan,  idsemester,  idtahun_ajaran,  idkelas,  nama,  alamat,  idkota,  agama,  jeniskelamin,  tgl_lahir,  tempat_lahir,  mhs,  st,  uas,  uts,  status_nim";
$proto0["m_strFrom"] = "FROM mahasiswa";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "idmahasiswa",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto5["m_sql"] = "idmahasiswa";
$proto5["m_srcTableName"] = "mahasiswa";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "idkejuruan",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto7["m_sql"] = "idkejuruan";
$proto7["m_srcTableName"] = "mahasiswa";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "idsemester",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto9["m_sql"] = "idsemester";
$proto9["m_srcTableName"] = "mahasiswa";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "idtahun_ajaran",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto11["m_sql"] = "idtahun_ajaran";
$proto11["m_srcTableName"] = "mahasiswa";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "idkelas",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto13["m_sql"] = "idkelas";
$proto13["m_srcTableName"] = "mahasiswa";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "nama",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto15["m_sql"] = "nama";
$proto15["m_srcTableName"] = "mahasiswa";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "alamat",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto17["m_sql"] = "alamat";
$proto17["m_srcTableName"] = "mahasiswa";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "idkota",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto19["m_sql"] = "idkota";
$proto19["m_srcTableName"] = "mahasiswa";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto0["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "agama",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto21["m_sql"] = "agama";
$proto21["m_srcTableName"] = "mahasiswa";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto0["m_fieldlist"][]=$obj;
						$proto23=array();
			$obj = new SQLField(array(
	"m_strName" => "jeniskelamin",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto23["m_sql"] = "jeniskelamin";
$proto23["m_srcTableName"] = "mahasiswa";
$proto23["m_expr"]=$obj;
$proto23["m_alias"] = "";
$obj = new SQLFieldListItem($proto23);

$proto0["m_fieldlist"][]=$obj;
						$proto25=array();
			$obj = new SQLField(array(
	"m_strName" => "tgl_lahir",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto25["m_sql"] = "tgl_lahir";
$proto25["m_srcTableName"] = "mahasiswa";
$proto25["m_expr"]=$obj;
$proto25["m_alias"] = "";
$obj = new SQLFieldListItem($proto25);

$proto0["m_fieldlist"][]=$obj;
						$proto27=array();
			$obj = new SQLField(array(
	"m_strName" => "tempat_lahir",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto27["m_sql"] = "tempat_lahir";
$proto27["m_srcTableName"] = "mahasiswa";
$proto27["m_expr"]=$obj;
$proto27["m_alias"] = "";
$obj = new SQLFieldListItem($proto27);

$proto0["m_fieldlist"][]=$obj;
						$proto29=array();
			$obj = new SQLField(array(
	"m_strName" => "mhs",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto29["m_sql"] = "mhs";
$proto29["m_srcTableName"] = "mahasiswa";
$proto29["m_expr"]=$obj;
$proto29["m_alias"] = "";
$obj = new SQLFieldListItem($proto29);

$proto0["m_fieldlist"][]=$obj;
						$proto31=array();
			$obj = new SQLField(array(
	"m_strName" => "st",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto31["m_sql"] = "st";
$proto31["m_srcTableName"] = "mahasiswa";
$proto31["m_expr"]=$obj;
$proto31["m_alias"] = "";
$obj = new SQLFieldListItem($proto31);

$proto0["m_fieldlist"][]=$obj;
						$proto33=array();
			$obj = new SQLField(array(
	"m_strName" => "uas",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto33["m_sql"] = "uas";
$proto33["m_srcTableName"] = "mahasiswa";
$proto33["m_expr"]=$obj;
$proto33["m_alias"] = "";
$obj = new SQLFieldListItem($proto33);

$proto0["m_fieldlist"][]=$obj;
						$proto35=array();
			$obj = new SQLField(array(
	"m_strName" => "uts",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto35["m_sql"] = "uts";
$proto35["m_srcTableName"] = "mahasiswa";
$proto35["m_expr"]=$obj;
$proto35["m_alias"] = "";
$obj = new SQLFieldListItem($proto35);

$proto0["m_fieldlist"][]=$obj;
						$proto37=array();
			$obj = new SQLField(array(
	"m_strName" => "status_nim",
	"m_strTable" => "mahasiswa",
	"m_srcTableName" => "mahasiswa"
));

$proto37["m_sql"] = "status_nim";
$proto37["m_srcTableName"] = "mahasiswa";
$proto37["m_expr"]=$obj;
$proto37["m_alias"] = "";
$obj = new SQLFieldListItem($proto37);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto39=array();
$proto39["m_link"] = "SQLL_MAIN";
			$proto40=array();
$proto40["m_strName"] = "mahasiswa";
$proto40["m_srcTableName"] = "mahasiswa";
$proto40["m_columns"] = array();
$proto40["m_columns"][] = "idmahasiswa";
$proto40["m_columns"][] = "idkejuruan";
$proto40["m_columns"][] = "idgelombang";
$proto40["m_columns"][] = "idsemester";
$proto40["m_columns"][] = "semester";
$proto40["m_columns"][] = "idtahun_ajaran";
$proto40["m_columns"][] = "iddosen";
$proto40["m_columns"][] = "idkelas";
$proto40["m_columns"][] = "nama";
$proto40["m_columns"][] = "alamat";
$proto40["m_columns"][] = "idprovinsi";
$proto40["m_columns"][] = "idkota";
$proto40["m_columns"][] = "email";
$proto40["m_columns"][] = "agama";
$proto40["m_columns"][] = "jeniskelamin";
$proto40["m_columns"][] = "tgl_lahir";
$proto40["m_columns"][] = "tempat_lahir";
$proto40["m_columns"][] = "kodepos";
$proto40["m_columns"][] = "negara";
$proto40["m_columns"][] = "tlp";
$proto40["m_columns"][] = "noktp";
$proto40["m_columns"][] = "cek";
$proto40["m_columns"][] = "keterangan";
$proto40["m_columns"][] = "mhs";
$proto40["m_columns"][] = "st";
$proto40["m_columns"][] = "uas";
$proto40["m_columns"][] = "uts";
$proto40["m_columns"][] = "idbea";
$proto40["m_columns"][] = "kelas";
$proto40["m_columns"][] = "thn_lulus";
$proto40["m_columns"][] = "jurusan";
$proto40["m_columns"][] = "1";
$proto40["m_columns"][] = "2";
$proto40["m_columns"][] = "file";
$proto40["m_columns"][] = "foto";
$proto40["m_columns"][] = "status_nim";
$proto40["m_columns"][] = "nama_instansi";
$proto40["m_columns"][] = "alamat_instansi";
$proto40["m_columns"][] = "tlp_instansi";
$proto40["m_columns"][] = "asal_sekolah";
$proto40["m_columns"][] = "asal_uni";
$proto40["m_columns"][] = "alamat_aktif";
$proto40["m_columns"][] = "nama_aktif";
$proto40["m_columns"][] = "pekerjaan_aktif";
$proto40["m_columns"][] = "tlp_aktif";
$proto40["m_columns"][] = "alamat_luar";
$proto40["m_columns"][] = "tlp_luar";
$proto40["m_columns"][] = "nama_ortu";
$proto40["m_columns"][] = "nama_ortu2";
$proto40["m_columns"][] = "profesi_ortu";
$proto40["m_columns"][] = "pendidikan_ortu";
$obj = new SQLTable($proto40);

$proto39["m_table"] = $obj;
$proto39["m_sql"] = "mahasiswa";
$proto39["m_alias"] = "";
$proto39["m_srcTableName"] = "mahasiswa";
$proto41=array();
$proto41["m_sql"] = "";
$proto41["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto41["m_column"]=$obj;
$proto41["m_contained"] = array();
$proto41["m_strCase"] = "";
$proto41["m_havingmode"] = false;
$proto41["m_inBrackets"] = false;
$proto41["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto41);

$proto39["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto39);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="mahasiswa";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_mahasiswa = createSqlQuery_mahasiswa();


	
																	
	
$tdatamahasiswa[".sqlquery"] = $queryData_mahasiswa;

$tableEvents["mahasiswa"] = new eventsBase;
$tdatamahasiswa[".hasEvents"] = false;

?>